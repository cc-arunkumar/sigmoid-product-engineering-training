const validateProduct = (req,res,next) =>{
    cons
}